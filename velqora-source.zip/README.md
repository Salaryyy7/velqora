# VELQORA

Complete React + TypeScript + Vite academic brand website.

## Run locally

Install Node.js 20.19+ or 22.12+, then run in this folder:

```sh
npm install
npm run dev
```

Open the URL printed by Vite. Production: `npm run build`, then `npm run preview`.

The lockfile also supports `pnpm install`, `pnpm dev`, and `pnpm build`.

## Assets and content

Products, executive profiles, press copy, and the central artwork mapping are in `src/data/content.ts`. Local assets are in `public/images`, and the three actual PDFs are in `public/downloads`.

No logo or photography was supplied. The typeset wordmark and neutral SVG campaign, packaging, and portrait studies are explicit placeholders. Replace these files with approved assets; preserve the original logo's proportions and transparency. The artwork is vector concept illustration, not campaign photography.

Google Fonts supplies Cormorant Garamond and Manrope with local serif/sans-serif fallbacks. Font loading requires internet; all illustration and PDF assets are local.

No backend, checkout, authentication, or personal data storage. The contact form validates in the browser and displays a demonstration confirmation. All products and people are fictional. The example-domain email is intentionally non-operational.

For static hosting, configure fallback routing to `index.html` so direct product/page URLs work.
