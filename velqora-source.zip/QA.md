# Verification

- TypeScript: `tsc -b` passed.
- Production: `vite build --configLoader runner` passed.
- Edge browser: all nine routes checked at 375, 768, 1024, and 1440 pixels (36 checks), one H1 per page, no horizontal overflow, no broken loaded images, no JavaScript page errors.
- Contact demonstration: valid submission displayed the explicit non-sending confirmation.
- Mobile navigation: open and Escape close passed.
- Reduced motion: smooth scrolling disabled as requested.
- All three download URLs returned valid PDF files.
- PDF documents rendered with Poppler and visually reviewed: press release 1 page, company facts 1 page, media kit 5 pages.

The built site was tested at http://127.0.0.1:4173. Vite development dependency scanning encountered a Windows sandbox directory-access restriction, so development mode was not verified in this environment. Production build and preview work. For a reliable local preview run `npm run build` and `npm run preview`.

No brand logo or photography was supplied. All local artwork and the temporary wordmark are identified placeholders. Replace them with approved assets before presenting the project as a final photographic campaign.
