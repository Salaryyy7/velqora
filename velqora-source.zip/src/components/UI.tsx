import {motion,useReducedMotion} from 'framer-motion';
import {ArrowUpRight,ArrowRight,Download} from 'lucide-react';
import {Link} from 'react-router-dom';
import type {ReactNode} from 'react';
import {products} from '../data/content';
export function Reveal({children,delay=0,className=''}:{children:ReactNode;delay?:number;className?:string}){const reduced=useReducedMotion();return <motion.div className={className} initial={reduced?false:{opacity:0,y:20}} whileInView={{opacity:1,y:0}} viewport={{once:true,amount:.12}} transition={{duration:.65,delay,ease:[.22,1,.36,1]}}>{children}</motion.div>}
export function PrimaryButton({to,children,secondary=false}:{to:string;children:ReactNode;secondary?:boolean}){return <Link className={secondary?'text-link':'button'} to={to}>{children}<ArrowRight size={17}/></Link>}
export function SectionHeading({label,title,children}:{label:string;title:string;children?:ReactNode}){return <Reveal><p className="eyebrow">{label}</p><h2>{title}</h2>{children}</Reveal>}
export function ProductCard({product:p}:{product:typeof products[number]}){return <article className="product-card"><Link to={'/collection/'+p.slug} className="product-image"><img src={p.image} alt={`${p.name} neutral packaging concept`} loading="lazy" width="700" height="850"/><span>DISCOVER <ArrowUpRight size={18}/></span></Link><div className="product-title"><h3>{p.name}</h3><span>{p.price} KZT</span></div><p>{p.category} <span className="volume">{p.volume}</span></p><PrimaryButton to={'/collection/'+p.slug} secondary>View product</PrimaryButton></article>}
export function EditorialImage({src,alt,statement}:{src:string;alt:string;statement?:string}){return <div className="editorial"><img src={src} alt={alt} loading="lazy" width="1600" height="1100"/>{statement&&<h2>{statement}</h2>}<span className="art-caption">VELQORA / CONCEPT ARTWORK</span></div>}
export function PressDownload({file,title,detail}:{file:string;title:string;detail:string}){return <a className="download" href={'/downloads/'+file} download><div><h3>{title}</h3><p>{detail} · PDF</p></div><Download size={22}/></a>}
