import React from 'react';
import ReactDOM from 'react-dom/client';
import {BrowserRouter,Routes,Route,useLocation} from 'react-router-dom';
import {MotionConfig,motion} from 'framer-motion';
import {useEffect} from 'react';
import {Navbar,Footer} from './components/Layout';
import {Home,Story,Collection,Product,People,Press,Contact,NotFound} from './pages/Pages';
import './styles/global.css';
function App(){const location=useLocation();useEffect(()=>{const titles:Record<string,string>={'/':'Better roots. Better hair.','/our-story':'Our Story','/collection':'Collection','/our-people':'Our People','/press-room':'Press Room','/contact':'Contact'};document.title=`VELQORA — ${titles[location.pathname]||'The Collection'}`},[location.pathname]);return <MotionConfig reducedMotion="user"><Navbar/><motion.main id="main" key={location.pathname} initial={{opacity:0}} animate={{opacity:1}} transition={{duration:.3}}><Routes><Route path="/" element={<Home/>}/><Route path="/our-story" element={<Story/>}/><Route path="/collection" element={<Collection/>}/><Route path="/collection/:slug" element={<Product/>}/><Route path="/our-people" element={<People/>}/><Route path="/press-room" element={<Press/>}/><Route path="/contact" element={<Contact/>}/><Route path="*" element={<NotFound/>}/></Routes></motion.main><Footer/></MotionConfig>}
ReactDOM.createRoot(document.getElementById('root')!).render(<React.StrictMode><BrowserRouter><App/></BrowserRouter></React.StrictMode>);
